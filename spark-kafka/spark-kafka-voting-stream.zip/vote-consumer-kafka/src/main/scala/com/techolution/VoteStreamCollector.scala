package com.techolution

import java.io.IOException
import java.sql.Timestamp
import java.util.Properties
import java.sql.DriverManager
import java.sql.Connection
import java.sql.Statement

import org.apache.spark.SparkConf
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._

import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.log4j. {
 Level,
 Logger
}

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types._
import org.apache.spark.sql. {
 Row,
 SQLContext,
 SaveMode,
 SparkSession
}
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferBrokers
import org.apache.spark.streaming. {
 Seconds,
 StreamingContext
}
import org.apache.spark.SparkContext


object Constants {

  val vote_json_schema = new StructType()
 .add(StructField("id", IntegerType, true))
 .add(StructField("userId", IntegerType, true))
 .add(StructField("voteFor", IntegerType, true))
 .add(StructField("votingTimeStamp", LongType, true))

  val rewardOne = 1
  val rewardZero = 0    //reward zero for competitors who got same number of votes in a time-frame
} 

object VoteStreamCollector {


 Logger.getLogger("org").setLevel(Level.WARN)
 Logger.getLogger("akka").setLevel(Level.WARN)
 private[this] lazy val logger = Logger.getLogger(getClass)
 var dbConnection :Connection = null
 var properties:Configuration = null
 val sharedResourceLock = "lock"

 def main(args: Array[String]): Unit = {

  try {
  properties = new PropertiesConfiguration(args(0))

  val votingStartTime = properties.getLong("voting.starttime")
  val votingStopTime = properties.getLong("voting.stoptime")

  val votingReportStartTime = roundMinute(votingStartTime, false)
  val votingReportStopTime = roundMinute(votingStopTime, true)
  val votingUserSpanInterval = properties.getLong("voting.userInterval")

 
   //flag to avoid - java.util.ConcurrentModificationException: KafkaConsumer is not safe for multi-threaded access
   var sparkConf = new SparkConf().set("spark.streaming.kafka.consumer.cache.enabled", "false")

   val spark = SparkSession.builder
    .appName("VoteStreamCollector")
    .config(sparkConf)
    .master("local[*]")
    .getOrCreate

   val streaming = new StreamingContext(spark.sparkContext, Seconds(properties.getInt("kafka.window")))

   val servers = properties.getString("kafka.brokers")

   val params = Map[String, Object](
    "bootstrap.servers" -> servers,
    "key.deserializer" -> classOf[StringDeserializer],
    "value.deserializer" -> classOf[StringDeserializer],
    "auto.offset.reset" -> "earliest",
    "group.id" -> "voting",
    "enable.auto.commit" -> (false: java.lang.Boolean)
   )

   val topics = Array(properties.getString("kafka.topics"))

   // create kafka direct stream object
   val stream = KafkaUtils.createDirectStream[String, String](
    streaming, PreferBrokers, Subscribe[String, String](topics, params))

  val sqlContext = new SQLContext(spark.sparkContext)
  var votesDataFrame = sqlContext.createDataFrame(spark.sparkContext.emptyRDD[Row], Constants.vote_json_schema)  

   

  type Record = ConsumerRecord[String, String]

   stream.foreachRDD((rdd: RDD[Record]) => {

      logger.info("Started processing Rdd records")

      val records = rdd.map(row => (row.value()))

      var recordsDF = spark.read.schema(Constants.vote_json_schema).json(records)   
      recordsDF.cache()

      logger.info("Received RDD records which has votes of size: " + recordsDF.count())



      if (recordsDF.count() > 0) {

      var persistOutput = scala.collection.mutable.Map[Long, List[Int]]()
        

           //thread-locking on shared resource
        recordsDF.foreach(row => {
         val items = row.mkString(",").split(",")
         
         logger.info("Received VoteRecord : userId" + items(1) + ", voteFor: " + items(2) + ", at timestamp: " + items(3))
         //Filter invalid vote-records

            /*
  //getting Iterator error with NPE - need a fix
      
         if(votesDataFrame != null) {
                //votesDataFrame.show()
                val items = row.mkString(",").split(",")
                var currentUser = items(1).toString.toInt
                var currentUserTimestamp = items(3).toString.toLong
                var interval = currentUserTimestamp - votingUserSpanInterval

                var count = votesDataFrame.count()

                //instead of deleting the rows, filtering the actual votes
                votesDataFrame = votesDataFrame.filter(col("userId").notEqual(currentUser) || col("votingTimeStamp") < currentUserTimestamp || col("votingTimeStamp") >= interval)
                var currentCount = votesDataFrame.count()

                logger.info( (currentCount - count) + " Votes  of User: " + currentUser + " were overridden in the interval between " +  interval + "-" + currentUserTimestamp )
                }    */

      })

        if (votesDataFrame.count() > 0) {
            votesDataFrame = votesDataFrame.union(recordsDF)
        } else {
           votesDataFrame = recordsDF
        }

            votesDataFrame.cache()
            logger.info("Total Votes in dataframe is: " + votesDataFrame.count())


            var rewardingStart = votingReportStartTime
            var nextStepReport = votingReportStartTime

            

            while (rewardingStart < votingReportStopTime) {
             //getting next minute epoch
             nextStepReport += 60000;

             persistOutput(rewardingStart) = getPerMinuteWinners(rewardingStart, nextStepReport, votesDataFrame)
             rewardingStart = nextStepReport
            }

            persistOutput(votingStartTime) = getPerMinuteWinners(votingStartTime, votingReportStartTime, votesDataFrame)
            persistOutput(votingReportStopTime) = getPerMinuteWinners(votingReportStopTime, votingStopTime, votesDataFrame)

            //thread-locking-release on shared resource     
         


          persistResults(persistOutput)

      }

   })

   // create streaming context and submit streaming jobs
   streaming.start()

   // wait to killing signals etc.
   streaming.awaitTermination()

   sys.ShutdownHookThread {
      if(dbConnection != null) {
          dbConnection.close
      }
        
  }

  } catch {
   case ex:
    Exception => logger.error("Error in Vote-Consumer: " + ex.getMessage, ex)

  }



 }
 


 def roundMinute(epoch_time: Long, is_floor: Boolean): Long = {
  //function to round epoch_time to next-minute
  //discarding milliseconds
  var timestamp = (epoch_time / 1000).toLong

  var roundingMinute = timestamp / 60
  if (is_floor == true) {

   return roundingMinute * 60 * 1000

  } else {


   //adding +60 seconds to get next minute 
   roundingMinute = roundingMinute.toLong * 60 + 60

   return roundingMinute * 1000

  }


 }

 def persistResults(output: scala.collection.mutable.Map[Long, List[Int]]) = {


  if (output.size > 0) {
   var insert_queries = "INSERT INTO results (timestamp, competitorId , reward) VALUES "

   output.foreach((element: (Long, List[Int])) => {
    val timestampReport = (element._1 / 1000).toLong

    if (element._2.size == 1) {
     insert_queries += " (" + timestampReport + "," + element._2(0) + ", " + Constants.rewardOne + "),"
    } else {

     //many competitors at this timestamp got same number of VoteStreamCollector
     //so rewarding zero for all competitors
     element._2.foreach(item => {
      insert_queries += " (" + timestampReport + "," + item + ", " + Constants.rewardZero + "),"

     })

    }

   })

  logger.info("Truncate Query for DB:  " + "truncate results")
  insert_queries = insert_queries.substring(0, insert_queries.length - 1)
  logger.info("Insert Query in DB:  " + insert_queries)

   var conn = getDBConnection();

   var stmnt: Statement = conn.createStatement
   stmnt.executeUpdate("truncate results")   
   stmnt.executeUpdate(insert_queries)
   stmnt.close

   
  } else {
   logger.info("No Records to persist")

  }


 }

 def getDBConnection(): Connection = {
  
  if(dbConnection == null || dbConnection.isClosed()) {
  val jdbcUrl = "jdbc:mysql://" + properties.getString("mysql.host") + ":3306/" + properties.getString("mysql.database")
  val connection: Connection = DriverManager.getConnection(jdbcUrl, properties.getString("mysql.user"), properties.getString("mysql.password"))
  dbConnection  = connection  
  }
  
  return dbConnection

 }

 def getPerMinuteWinners(epoch_time_1: Long, epoch_time_2: Long, totalVotesDF: DataFrame): List[Int] = {

  var filtered = totalVotesDF.filter(totalVotesDF("votingTimeStamp") >= epoch_time_1).filter(totalVotesDF("votingTimeStamp") < epoch_time_2)
  var competitorIds = List.empty[Int]

  if (filtered.count() > 0) {
   var grouped_df = filtered.groupBy("voteFor").count().orderBy(desc("count"))
   
   logger.debug("Per minute votes for: " + epoch_time_1 +"-" + epoch_time_2 + "\n" + grouped_df.show())

   var max_count = -1
   var isIteratedFirstTime = true
   grouped_df.collect.foreach(row => {

    val items = row.mkString(",").split(",")
    val votesCount = items(1).toString.toInt

    if (isIteratedFirstTime) {
     isIteratedFirstTime = false
     competitorIds = competitorIds:+ items(0).toString.toInt
     max_count = votesCount

    } else if (max_count == votesCount) {
     competitorIds = competitorIds:+ items(0).toString.toInt
    } else {
     //skipping since other competitors got less votes
    }

   })

  }

  return competitorIds

 }



}

