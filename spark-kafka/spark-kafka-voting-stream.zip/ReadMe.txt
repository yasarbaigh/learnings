1. Tested in Environment
	Ubuntu : 16
	JDK: 1.8.0_161
	Maven: 3.3.9
	Kafka: kafka_2.11-2.0.0
	Spark: Spark: 2.2.2

2. Provide properties in voting.properties
	2.1		Voting start-time and end-time shoule be epoch-time with milli-seconds
	2.2		Voting will start at start-time only, till that time, it will wait.

3. Reports are persisted in Mysql-DB
	3.1		If error in persisting, then it will updated in result.csv at vote_stream_consumer.py directory
	3.2		Assumptions, if many competitors got same number of votes in a minute, then all top-competitors with same
			number of votes will get reward as zero (0), even its persisted.

4.	Much more kafka-messages can also be read in off-set range approach. But due to time-constraints, couldn't concentrate on it.

5.	Reward points are stored for every minute-timestamp i.e.
	Reward point of Votes received during between 2018-11-19 14:11:00:000 - 2018-11-19 14:11:59:999
	will be stored in epoch-time of  2018-11-19 14:11:00


6.	Optimization at levels can be done further.



=============================
Scripts for DB:


DROP TABLE IF EXISTS `results`;
CREATE TABLE IF NOT EXISTS `results` (
  `timestamp` int(20) DEFAULT NULL,
  `competitorId` int(11) DEFAULT NULL,
  `reward` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-----------------------------------

Commands to Execute

<extrat-source-folder>
#cd vote-generator-kafka
#mvn clean package;java -jar target/vote-generator-kafka-0.1.jar ../voting.properties


<spark-bin-folder>
#spark-submit --packages org.apache.spark:spark-streaming-kafka_2.11:1.6.0 vote_stream_consumer.py ../voting.properties

=============================