-- Every minute winner
SELECT timestamp as TimeStamp, competitorId  as Competitor_ID, count(competitorId) as Rewards FROM results WHERE reward = 1 GROUP BY timestamp, competitorId ORDER BY timestamp;

-- number of competitors got same number of votes @ given minute
SELECT timestamp as TimeStamp, count(competitorId) as count FROM results WHERE reward = 0 GROUP BY timestamp  ORDER BY timestamp;


-- winner -list

Select competitorId as Competitor_ID, count(reward) as Rewards  from results  WHERE reward = 1 GROUP BY competitorId  order by Rewards desc;