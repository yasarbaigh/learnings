import csv, logging
           
import mysql.connector
from mysql.connector import Error



logging.basicConfig(filename="/tmp/log/vote-consumer.log", format='%(message)s',
                    level=logging.INFO, filemode='a')

class PropertiesReader(object):
    
    def __init__(self, filename):
        self.filename = filename
        self.properties = self.read_properties()
        self.connection = None

    def read_properties(self):   
        result = { }
        with open(self.filename, "r") as csvfile:
            reader = csv.reader(csvfile, delimiter=str('='), escapechar=str('\\'), quoting=csv.QUOTE_NONE)
            for row in reader:
                # skipping empty-lines or begins with hash and removing corner quotes
                if len(row) == 2:
                    key = str.strip(row[0])
                    
                    if key.startswith("#") :
                        continue  # its a comment
                    
                    # removing quotes
                    value = str.strip(row[1]).replace("'", "'").replace('"', '"') 
                    result[key] = value  
                
        return result

    def round_minute(self, epoch_time, is_floor=True):
        # function to round epoch_time to next-minute
        #discarding milliseconds
        epoch_time = epoch_time/1000
        if is_floor :
            return int(((int(epoch_time / 60)) * 60) * 1000)
        else:
            return int(((int((epoch_time / 60)) * 60) + 60) * 1000)
            

    def get_int(self, key, default_value=0):
        value = self.properties.get(key)    	
        if value:
            return int(value)
        else:
            default_value
            
    def get(self, key):
        return self.properties.get(key)       
        

    def get_db_conn(self):
        try:
            if self.connection is None:                
                self.connection = mysql.connector.connect(host= self.get('mysql.host'),
                                 database=self.get('mysql.database'),
                                 user=self.get('mysql.user'),
                                 password=self.get('mysql.password'))
            
            return self.connection;
                   
        except mysql.connector.Error as error :
            self.connection.rollback()  # rollback if any exception occured
            logging.error("Failed inserting record into python_users table {}".format(error))
        
    
