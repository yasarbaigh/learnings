import json, sys, ast, logging, threading, csv

import pandas as pd

from datetime import datetime

from pyspark import SparkConf, SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
from pyspark.sql import DataFrame
from pyspark.sql.types import * 

import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode

logging.basicConfig(filename="/tmp/log/vote-consumer.log", format='%(asctime)s %(levelname)-8s %(message)s',
                    level=logging.INFO, filemode='a', datefmt='%Y-%m-%d %H:%M:%S')


#custom-utils in same package
from utils import PropertiesReader
properties = PropertiesReader(sys.argv[1])


voting_start_time = properties.get_int("voting.starttime")
voting_stop_time = properties.get_int("voting.stoptime")  
 
interval_for_user_to_vote = properties.get_int("voting.userInterval")
competitors = properties.get_int("voting.competitors") 
audiences = properties.get_int("voting.audiences")

voting_report_start_time = properties.round_minute(voting_start_time, False)
voting_report_stop_time = properties.round_minute(voting_stop_time, True)

total_vote_df = None
process_records_lock = threading.Lock()

# in each minute, if only one competitor gets max votes, reward = 1
reward_one = 1
# in each minute, if many competitors get max votes, reward = 0
reward_zero = 0

def get_per_minute_winners(timestamp_1, timestamp_2):
        
    filtered = total_vote_df[(total_vote_df.votingTimeStamp >= timestamp_1) & (total_vote_df.votingTimeStamp < timestamp_2)]
    
    user_ids = []
    max_grouped_number = -1
    is_iterated_first_time = True

    if (len(filtered) > 0):
        grouped_df = filtered.groupby('voteFor').userId.count().sort_values(ascending=False).reset_index(name='count')
    
        for index, item in grouped_df.iterrows():
            
            count = item[1]

            if(is_iterated_first_time):
                max_grouped_number = count
                is_iterated_first_time = False
            elif max_grouped_number == count:            
                user_ids.append(item[0])
            else:
                # received groupby count value ,lesser than max value
                # since for 1 minute, only one user can get 1 reward point
                break

    return user_ids


def persist_reports(persist_records):
    
    
    values_to_insert = []
    
    if len(persist_records) > 0 :
        for timestamp, voteFor in persist_records.items():
            if len(voteFor) == 1 :
                values_to_insert.append([timestamp/1000, voteFor[0], reward_one])
            else :
                # for given minute many competitors got same number of max-votes
                for competitorId in voteFor :
                    values_to_insert.append([timestamp/1000, competitorId, reward_zero])  
    
        insert_queries = "INSERT INTO results (timestamp, competitorId , reward) VALUES "
        values = ''
        for record in values_to_insert:
            values += "(" + str(record[0]) + ',' +  str(record[1]) + ',' + str(record[2]) + "),"
        
        #trimming last comma
        insert_queries += values[:-1]
        
        logging.info("Inserting queries:") 
        logging.info(insert_queries)
        
        cursor = None;
        try:
            conn = properties.get_db_conn()
            cursor = conn.cursor()
            cursor.execute("truncate table results")
            cursor.execute(insert_queries)
            conn.commit()
        except mysql.connector.Error as error :
            conn.rollback() #rollback if any exception occured
            logging.error("Failed inserting record into python_users table {}".format(error))
            logging.info("writing data in result.csv file")
            with open('results.csv', 'w') as csv_file:
                writer = csv.writer(csv_file)
                writer.writerow('timestamp,competitorId,reward')
                for row in values_to_insert:                 
                    writer.writerow(str(row[0]) + ',' +  str(row[1]) + ',' + str(row[2]))
                
            
        finally:
            #closing cursor connection.
            if cursor :
                cursor.close
            
    

def process_records(records_list):
    
    process_records_lock.acquire()

    records_df = pd.DataFrame(records_list)

    global total_vote_df
    if not (total_vote_df is None):
        for item in records_list:            
            # delete votes of user, btwn item-votingts to item-votings-spandelay
            min = item['votingTimeStamp'] - interval_for_user_to_vote 
            votes_to_discard = total_vote_df[(total_vote_df.userId == item['userId']) & (total_vote_df.votingTimeStamp <= item['votingTimeStamp']) & (total_vote_df.votingTimeStamp > min)]
            if(len(votes_to_discard) > 0) :
                logging.info("Votes of User:" + str(item['userId']) + " are overrided from timestamp:" + str(item['votingTimeStamp']) )
                total_vote_df.drop(votes_to_discard.index)
        
    
    
    
    if total_vote_df is None:         
        total_vote_df = records_df 
    else :
        total_vote_df = pd.concat([total_vote_df, records_df], ignore_index=True)   
    
    total_votes = len(total_vote_df)
    logging.info("After overriding the votes within the overide-interval, total-votes size" + str(total_votes))
    
    
    # go for minute result, at 10-15th second of  a minute
    # seconds = int(datetime.now().strftime('%S'))
    persist_output = dict()
    logging.info("Started calculating results.")
    if True :  # seconds > 10 and seconds < 15 :        
        rewarding_start = voting_report_start_time
        next_step_report = voting_report_start_time
        while(rewarding_start <= voting_report_stop_time):
            next_step_report += 60000;
            
            persist_output[rewarding_start] = get_per_minute_winners(rewarding_start, next_step_report)            
            
            # next-minute-epoch    
            rewarding_start = next_step_report
              
        persist_output[voting_start_time] = get_per_minute_winners(voting_start_time, voting_report_start_time)
        persist_output[voting_start_time] = get_per_minute_winners(voting_report_stop_time, voting_stop_time)
        
    
    process_records_lock.release()
    # persisting records might take time, so releasing the lock on shared-resource
    persist_reports(persist_output)


def handleRecords(message):
    records = message.collect()    
    records_list = []
    
    for record in records:
        
        item = ast.literal_eval(str(record[1]))        
        # validate records of vote, such as within timestamp and correct-user and competitors
        if item['voteFor'] > 0 & item['voteFor'] <= competitors  & item['userId'] > 0 & item['userId'] <= audiences :
            records_list.append(item)

    
    logging.info("Received Kafka messages of size " + str(len(records_list)))

    # print(records_list) 
    if(len(records_list) > 0) :    
        process_records(records_list)
        

def set_logging_level(sc):
    logger = sc._jvm.org.apache.log4j
    logger.LogManager.getLogger("org").setLevel(logger.Level.ERROR)
    logger.LogManager.getLogger("akka").setLevel(logger.Level.ERROR)
    
    
def process_streams():

    
    sc = SparkContext(appName="Vote_Stream_Counter")
    ssc = StreamingContext(sc, 10)
    set_logging_level(sc)

    brokers = properties.get("kafka.brokers")
    topic = properties.get("kafka.topics")  

    kafkaParams = {"metadata.broker.list": brokers}
    kafkaParams["auto.offset.reset"] = "smallest"
    # kafkaParams["enable.auto.commit"] = "false"
    
    logging.info("Kafka Brokers")  
    logging.info(brokers)  
    logging.info("Kafka Topics")  
    logging.info(topic)  

    kvs = KafkaUtils.createDirectStream(ssc, [topic], kafkaParams)
    kvs.foreachRDD(handleRecords)

   
    ssc.start()
    ssc.awaitTermination()


if __name__ == "__main__":
    process_streams()
   
   
   
