package com.techolution;

import java.io.File;
import java.util.Date;
import java.util.Timer;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.Logger;

import com.techolution.common.Constants;
import com.techolution.producer.Producer;
import com.techolution.voting.VotingTask;

public class VoteGenerator {
	private static final Logger LOGGER = Logger.getLogger(VoteGenerator.class);

	private static Configuration conf;

	public static void main(String[] args) {
		try {
			conf = new PropertiesConfiguration(new File(args[0]));

			final Producer producer = new Producer(conf);

			Runtime.getRuntime().addShutdownHook(new Thread(() -> {
				LOGGER.info("VoteGeneration is stopping ...");

				producer.close();
			}));

			//adding 1000 epoch for milliseconds
			final long startTime = conf.getLong(Constants.VOTING_START_TIME);
			final Date startDateTime = new Date(startTime);
			
			 
			final Date stopTime = new Date(conf.getLong(Constants.VOTING_STOP_TIME));

			final Timer timer = new Timer();
			final VotingTask task = new VotingTask(timer, conf, producer);
			LOGGER.info("Vote Generation will start at: " + startDateTime.toString());
			LOGGER.info("Vote Generation will stop at: " + stopTime.toString());
			timer.schedule(task, startDateTime);
			

		} catch (final Exception ex) {
			LOGGER.error(ex.getMessage(), ex);
		}

	}

}