package com.techolution.beans;

import java.io.Serializable;

public class VoteBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int userId, voteFor, id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	private long votingTimeStamp;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getVoteFor() {
		return voteFor;
	}

	public void setVoteFor(int voteFor) {
		this.voteFor = voteFor;
	}

	public long getVotingTimeStamp() {
		return votingTimeStamp;
	}

	public void setVotingTimeStamp(long votingTimeStamp) {
		this.votingTimeStamp = votingTimeStamp;

	}

}
