package com.techolution.voting;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.configuration.Configuration;
import org.apache.log4j.Logger;

import com.techolution.beans.VoteBean;
import com.techolution.common.Constants;
import com.techolution.producer.Producer;
import com.techolution.utils.JsonUtils;

public class VotingTask extends TimerTask {

	private static final Logger LOGGER = Logger.getLogger(VotingTask.class);
	final Timer timer;
	final Configuration conf;
	final Producer producer;
	private static final Random RANDOM = new Random();
	static int countc = 1;

	public VotingTask(Timer timer, Configuration conf, Producer producer) {
		this.timer = timer;
		this.conf = conf;
		this.producer = producer;
	}

	@Override
	public void run() {
		LOGGER.info("Vote Generation is started.");
		try {
			long currenTime = System.currentTimeMillis();
			// adding 1000 for milliseconds
			final long startTime = conf.getLong(Constants.VOTING_START_TIME);
			final long stopTime = conf.getLong(Constants.VOTING_STOP_TIME);

			// sleep time in milliseconds between 2 votes
			final int sleep = conf.getInt(Constants.VOTING_DELAY_INTERVAL);

			while (currenTime >= startTime && currenTime < stopTime) {

				final VoteBean record = generateVote();

				final String message = JsonUtils.serialize(record);
				producer.produce(message);				

				LOGGER.info("Pushed message to kafka: " + message);
				
				Thread.sleep(sleep);
				currenTime = System.currentTimeMillis();
			}
		} catch (final Throwable t) {
			LOGGER.error(t.getMessage(), t);
		} finally {
			timer.cancel();
			LOGGER.info("Voting Timer stopped.");
		}
	}

	/**
	 * Generates random vote-record
	 *
	 * @return Returns Vote object with random values
	 */
	private VoteBean generateVote() {
		final VoteBean bean = new VoteBean();
		// adding one to random-int to avoid 0 as label of user or competitor
		bean.setUserId(RANDOM.nextInt(conf.getInt(Constants.VOTING_AUDIENECES)) + 1);
		bean.setVoteFor(RANDOM.nextInt(conf.getInt(Constants.VOTING_COMPETITORS)) + 1);

		bean.setVotingTimeStamp(System.currentTimeMillis());
		bean.setId(countc++);
		return bean;
	}
}