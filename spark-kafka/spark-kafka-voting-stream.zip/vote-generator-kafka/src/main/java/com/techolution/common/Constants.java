package com.techolution.common;

public class Constants {

	public static final String VOTING_START_TIME = "voting.starttime";
	public static final String VOTING_STOP_TIME = "voting.stoptime";
	public static final String VOTING_COMPETITORS = "voting.competitors";

	public static final String VOTING_AUDIENECES = "voting.audiences";
	public static final String VOTING_DELAY_INTERVAL = "voting.delayInterval";

	public static final String KAFKA_BROKERS = "kafka.brokers";
	public static final String KAFKA_TOPICS = "kafka.topics";
	public static final String KAFKA_BATCH_SIZE = "kafka.batchsize";

}