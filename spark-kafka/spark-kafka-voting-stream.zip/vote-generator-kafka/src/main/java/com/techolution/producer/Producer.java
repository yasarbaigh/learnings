package com.techolution.producer;

import java.util.Properties;

import org.apache.commons.configuration.Configuration;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.techolution.common.Constants;

public class Producer {

	final Configuration conf;
	private final KafkaProducer<String, String> producer;

	public Producer(Configuration conf) {
		this.conf = conf;
		final String brokers = conf.getString(Constants.KAFKA_BROKERS);

		final Properties props = new Properties();
		props.put("bootstrap.servers", brokers);
		props.put("acks", "all");
		props.put("retries", 0);
		props.put("batch.size", conf.getInt(Constants.KAFKA_BATCH_SIZE));
		props.put("linger.ms", 1);
		props.put("buffer.memory", 33554432);
		props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

		producer = new KafkaProducer<>(props);
	}

	public void produce(String data) {
		producer.send(
				new ProducerRecord<>(conf.getString(Constants.KAFKA_TOPICS), "" + System.currentTimeMillis(), data));
	}

	public void close() {
		producer.close();
	}
}